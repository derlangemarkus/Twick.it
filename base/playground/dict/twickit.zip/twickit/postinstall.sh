#!/bin/sh
cd $2
mv "Twicktionary.dictionary/_Twicktionary.dictionary" "./._Twicktionary.dictionary"
/System/Library/CoreServices/FixupResourceForks .
exit 0