<?php
readfile("http://twickit.de/interfaces/api/stats.json");
?>